package at.fhv.game.model;

public enum GameStatus {
    CREWMATES_WIN,
    IMPOSTORS_WIN,
    LOBBY,
    IN_GAME,
}
