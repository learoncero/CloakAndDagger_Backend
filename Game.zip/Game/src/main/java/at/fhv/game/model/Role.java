package at.fhv.game.model;

public enum Role {
    CREWMATE,
    IMPOSTOR,
    CREWMATE_GHOST,
    IMPOSTOR_GHOST
}
